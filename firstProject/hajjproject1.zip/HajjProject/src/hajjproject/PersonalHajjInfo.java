
package hajjproject;


import java.util.Random; 
import java.util.Scanner; 
//this is the personal information class we will be taking the user's personal information and we will add a random number 
//the random number will be a the booking reference number we will take it to the campaign class

public class PersonalHajjInfo {
    //fields
    private boolean residentOrVisitor;
    public String fullName;
    private String country;
    private int age;
    private boolean vaccinate;
    private String iD;
    public int oneOrTwo;
    private int bookNum;
    Scanner scan = new Scanner (System.in);
    
    //constructor that takes all arguments
    public PersonalHajjInfo(boolean residentOrVisitor, String country, int age, boolean vaccinate, String iD, int booknum) {
        this.residentOrVisitor = residentOrVisitor;
        this.country = country;
        this.age = age;
        this.vaccinate = vaccinate;
        this.iD = iD;
        this.bookNum = booknum;
    }
    
    
    //constructor that takes no arguments
    public PersonalHajjInfo() {
        residentOrVisitor = true;
        fullName = "";
        country = "";
        age = 0;
        vaccinate = true;
        iD = "";
    
    }
    //COPY CONSTRUCTOR
    public PersonalHajjInfo(PersonalHajjInfo tempPersonal){ 
        this.residentOrVisitor = tempPersonal.residentOrVisitor;
        this.fullName = tempPersonal.fullName;
        this.country = tempPersonal.country;
        this.age = tempPersonal.age;
        this.vaccinate = tempPersonal.vaccinate;
        this.iD = tempPersonal.iD;
        this.bookNum = tempPersonal.bookNum;
    }
   
    //this is the last constructor
    
    public void setCountry(String country1) {
        country1 = scan.nextLine();
        this.country = country1;
    }
    //getters 
    public String getCountry() {
        return country; 
    }
    
    public void setID(String id){
        id = scan.nextLine();
        iD = id;
    }    
    public String getID(){
        return iD;
    }
    
    
    public void setResidentOrVisitor(boolean residentOrVisitor) {
        int choosingNum = scan.nextInt();
        if(choosingNum ==1 ){
            residentOrVisitor = true;
        }
        else if(choosingNum == 2){
            residentOrVisitor = false;
        }
        else{ //if chosen other than 1 or 2
            while(choosingNum != 1 && choosingNum!=2){
                System.out.println("Wrong input");
                System.out.print("Try again: ");
                choosingNum=scan.nextInt();
            }
            
        }
        this.residentOrVisitor = residentOrVisitor;
    }
    public String getResidentOrVisitor() {
        if(residentOrVisitor == true){
            return "resident";
        }
        else{
            return "visitor";   } 
    }

    
    public void setAge(int age) {
        age = scan.nextInt();
        this.age = age;
    }
    
    public int getAge() {
        return age;
    }
    

    public void setVaccinate(boolean vaccine){
        
        oneOrTwo= scan.nextInt();
        
        if(oneOrTwo == 1){
            vaccine = true;
        }
        else if(oneOrTwo == 2){
            vaccine = false;
        }
        else{
            while(oneOrTwo != 1 && oneOrTwo!=2){
                System.out.println("Wrong input");
                System.out.print("Try again: ");
                oneOrTwo=scan.nextInt(); 
        }
        
        }
        this.vaccinate = vaccine;
    }
    
    public String getVaccinate(){
        if(vaccinate == true)
            return "Vaccinated";
        else
            return "NOT vaccinated";
        
    }
    public int getbooknum(){
        return bookNum;
    }   
    
    public void setcreateBookingNumber(){
	
	Random r=new Random();
		
	int number=r.nextInt(50000);
	bookNum = number;	
	}
    
    //string method
    public String toString(){
        return "\nYour full name is: " +fullName+ "\nYou are a: "+getResidentOrVisitor()+"\nYour ID is: "+iD+"\nYou are from: "+country+
                "\nYour age is: "+age+"\nYou are: "+getVaccinate()+"\nYour booking number is: "+getbooknum();
    }
    
}
