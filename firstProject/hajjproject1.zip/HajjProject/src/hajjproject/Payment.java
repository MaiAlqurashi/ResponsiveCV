
package hajjproject;

import java.util.Scanner;
//here is the payment class, we will call the price from the campaign class and let the user choose the payment method

public class Payment {
    private String cardHolderFullName;
    private String cardNumber;
    private int cvv;
    private int paymentmethod;
    private CampaignChoice cc; 
    private PersonalHajjInfo phi;
    
    Scanner scan = new Scanner (System.in);
    
    public Payment(String cardHolderFullName, String cardNumber, int cvv,int paymeth, CampaignChoice cc, PersonalHajjInfo phi) {
        this.cardHolderFullName = cardHolderFullName;
        this.cardNumber = cardNumber;
        this.cvv = cvv;       
        this.paymentmethod = paymeth;
        this.cc = new CampaignChoice(cc); 
        this.phi = new PersonalHajjInfo(phi); //this is the copy constructor
    }
    
    public Payment(){
        cardHolderFullName = "";
        cardNumber = null;
        cvv = 000;
      
    }
    //campaign choice
    public CampaignChoice getCampaignChoice(){
        return new CampaignChoice(this.cc); //return new object
    }
    
    public PersonalHajjInfo getPersonalInfo(){
        return new PersonalHajjInfo(phi);
    }
    
    public void setpaymentMethod(){
        int i;     
        String methods[] = {"visa" , "mastercard" , "paypal", "apple pay"};
        for(int index = 0; index<4; index++){
        System.out.println("Please enter " +(index)+ " if you choose " +methods[index]+ " ");   
        } 
        i = scan.nextInt();
        scan.nextLine(); //because im reading string after it
        this.paymentmethod = i;
    }    
    
    public String getpaymentMethod(){
        if (paymentmethod == 0){
            return "visa";
    }
        else if(paymentmethod == 1){
            return "mastercard";
        }
        else if(paymentmethod == 2){
            return "paypal";
        }
        else if(paymentmethod == 3){
            return "apple pay";
        }
        else{
            return "You did not choose the right number";
        }
    }
    
    
    public void setCardHolderFullName(String cardHolderFullName) {
        cardHolderFullName = scan.nextLine();
        this.cardHolderFullName = cardHolderFullName;
    }

    public void setCardNumber(String cardNumber) {
        cardNumber = scan.nextLine();
        this.cardNumber = cardNumber;
    }

    public void setCvv(int cvv) {
        cvv = scan.nextInt();
        this.cvv = cvv;
    }

    public String getCardHolderFullName() {
        return cardHolderFullName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public int getCvv() {
        return cvv;
    }
    
    
    public String toString(){
        return "\nYour card name is: "+cardHolderFullName+ "\nYour card number is: "+
                cardNumber+ "\nYour cvv is: "+cvv+ "\nYour payment method is: "+paymentmethod+
                "\nYour personal information(FOR YOUR BANK SECURITY): "+this.phi+
                "\nYour Campaign choice (FOR PRICE AND CONFIRMATION): "+this.cc;
    }
    

}
