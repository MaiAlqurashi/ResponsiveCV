
package hajjproject;

import java.util.Scanner;
//this is a campaign choice class there are three different campaigns each has a different price
//user will be choosing one of these campaigns then we will take the price to the next class which is the payment class

public class CampaignChoice {
    //fields
    private double budget;
    private int campChoice;
    final int campA = 10000;
    final int campB = 7000;
    final int campC = 5000;
    int finalprice;
    
    
    //add constructor
    public CampaignChoice(){
        budget = 0;
        campChoice=0;
        finalprice = 0;
    }

    Scanner scan = new Scanner (System.in);
    
    
    public CampaignChoice(double budget, int campChoice, int finalprice,final int campA, final int campB, final int campC) {
        this.budget = budget;
        this.campChoice = campChoice;
        this.finalprice = finalprice;
        
    }
    //COPY CONSTRUCTOR
    public CampaignChoice (CampaignChoice tempCC){
        this.budget = tempCC.budget;
        this.campChoice = tempCC.campChoice;
        this.finalprice = tempCC.finalprice;        
    }
   
    public void setchoices(int camChoice){
        
        System.out.println("Please enter (1) if you choose campaign A: " +campA+ "SR");
        System.out.println("Please enter (2) if you choose campaign B: " +campB+ "SR");
        System.out.println("Please enter (3) if you choose campaign C: " +campC+ "SR");
        camChoice = scan.nextInt();        
        this.campChoice = camChoice;
    }
    

    public int getchoices(){
        return campChoice;
    }

    public void setfinalp (int price){
        if(this.campChoice== 1)
        {
            price=campA;
        }
        else if(this.campChoice== 2)
        {
            price=campB;
        }
        else if(this.campChoice== 3)
        {
            price = campC;
        }
        finalprice = price;
    }
    
    public int getFinalPrice(){
        return finalprice;
    }
     
    public void setBudget(double budget) {
        budget = scan.nextDouble();
        this.budget = budget;
        scan.nextLine(); //printing string after it
    }
    
    public double getBudget() {
        return budget;
    }
    
     
    
    //printing data method
    public String toString(){
        String text = "\nYour budget is: " + this.budget+ "SR"+            
                    "\nYour campaign choice is: " +campChoice
                    +"\nYour final price is: "+this.finalprice;
        return text;
    }
  
}
