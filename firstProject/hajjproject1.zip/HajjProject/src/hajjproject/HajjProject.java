//Mai Alqurashi
//ID: 2008060
package hajjproject;

import java.io.*;
import java.util.Scanner;
    //this is the main class we will ask user for their personal information firs, campaign choice, then payment.
    

public class HajjProject {

    
    public static void main(String[] args) throws FileNotFoundException {
        
        Scanner scan = new Scanner (System.in); //scanner object
        PrintWriter outputhajj = new PrintWriter("Hajj Application.txt");
        
        
        System.out.println("Welcome to your hajj booking!");
        System.out.println("-------------------------------------");
        
        //haj without arguments put setters
        
        PersonalHajjInfo haj1 = new PersonalHajjInfo();
        
        System.out.print("Please enter your full name: ");
        //since name is public
        haj1.fullName = scan.nextLine();
        
        //initializing variables
        int age = 0, booknum= 0; //see whats wrong with it having to be initialized
        String country = "" , iD = "";
        boolean vaccine = true, rOrV = true;
        
        System.out.print("Please enter your country: " );
        haj1.setCountry(country);
        System.out.print("Please enter your ID number: ");
        haj1.setID(iD);
        System.out.print("Please enter 1 if you are vaccinated, and 2 if you are NOT vaccinated: ");
        haj1.setVaccinate(vaccine); 
        if(haj1.oneOrTwo == 2){ //VALIDATION
            System.out.println("Sorry, you have to be vaccinated to go to hajj");
            System.exit(0);
        }
        System.out.print("Please enter 1 if you are a resident, and 2 if you are a visitor: ");
        haj1.setResidentOrVisitor(rOrV);
        System.out.print("Please enter your age: ");
        haj1.setAge(age);
        
        haj1.setcreateBookingNumber();
   
        System.out.println("\n-------------------------------------");
    
        CampaignChoice choice = new CampaignChoice(0,0, 0, 10000, 7000, 5000);
        //object without arguments
        
        double budget = 0;
        int campChoice = 0;
        int price = 0;
  
        System.out.print("Please enter your budget in SR ");
        choice.setBudget(budget);
        choice.setchoices(campChoice);
        choice.setfinalp(price);
           
        //PAYMENT
        
        System.out.println("\n-------------------------------------");
        
        Payment pay = new Payment("","", 0, 0 , choice, haj1);   //object interaction     
        
        String cardHolderName = "" , cardNumber = "";
        int cvv = 0, method = 0;        
       
        pay.setpaymentMethod();
        
        System.out.print("Please enter Card Holder Full Name: "); //why isnt letting me access?        
        pay.setCardHolderFullName(cardHolderName); 
        
        System.out.print("Please enter Card Number: ");
        pay.setCardNumber(cardNumber);
        
        System.out.println("Please enter card CVV number (three digits at the back of the card): ");
        pay.setCvv(cvv);
      
       outputhajj.print(haj1.toString());
       outputhajj.print(choice.toString());
       outputhajj.print(pay.toString()); 
       outputhajj.close(); //close
       
      // reading from the file
       String line;
 
       File read = new File("Hajj Application.txt"); 
       Scanner scan_file = new Scanner(read);
    
       for(int i=0; i<27; i++){
           line = scan_file.nextLine();
           System.out.println(line);
       }
       
        scan_file.close();
      
        
    }
    
}
